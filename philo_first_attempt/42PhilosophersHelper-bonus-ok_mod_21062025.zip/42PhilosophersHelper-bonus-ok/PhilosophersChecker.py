#!/usr/bin/env python3

import subprocess
import fcntl
import time
import os
import signal
import sys

if len(sys.argv) < 2:
	print("Please give command uWu")
	exit(1)

# === CHANGE THIS ===
command = sys.argv[1]
timeout = int(sys.argv[2]) if len(sys.argv) > 2 else 10
# === NO TOUCHY ===

# Vars
pipe = None
pid = 0

# Create datastream from demodulator
pipe = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)

# Make subprocess non-blocking
fcntl.fcntl(pipe.stdout.fileno(), fcntl.F_SETFL, os.O_NONBLOCK)

time.sleep(1)

# If cannot open:
if pipe.poll() != None:
	print("Never started...")
	exit(1)
else:
	pid = pipe.pid
	print("PID: %s" % (pid))

# Do some counting
for x in range(0, timeout):
	print(timeout - x)
	if pipe.poll() != None:
		print("Died :(")
		exit(1)
	time.sleep(1)

# Kill dem!
# 1) Extrae el nombre del ejecutable real
exe_name = command.split()[0]

# 2) Manda SIGTERM a ese nombre
#    (o mejor aun, directamente al PID que arrancaste)
try:
    os.kill(pipe.pid, signal.SIGTERM)
except ProcessLookupError:
    pass

# 3) Asegúrate de cerrar el proceso “shell” también
pipe.kill()

# STONKS!
print("Worked! :D")
